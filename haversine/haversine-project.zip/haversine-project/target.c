
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

#include  <sys/types.h>
#include  <dirent.h>
#include <libgen.h>
#include <limits.h>
#include <unistd.h>



void directorySearch(void){
    //use current working directory
    char cwd[PATH_MAX];
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        printf("Current working dir: %s\n", cwd);
        printf("path size: %lu", strlen(cwd));
    } else {
        perror("getcwd() error");
    }

    DIR             *dirp;
    struct dirent   *dp;
    
    dirp = opendir(cwd);
    if(dirp == NULL) {
        perror("error");
    }
    
    while((dp = readdir(dirp)) != NULL) {
        // printf( "%s\n", dp->d_name );
    }
    closedir(dirp);
}









// TODO Remove whitespace from end of fileName
bool fileExists(char * filename){
    // removeSpaces(filename);
    FILE *fp;
    fp = fopen(filename, "r");
    if(fp == NULL){
        // printf("    %s not found\n", filename);
        return false;
    }
    else{
        // printf("    %s has been found\n", filename);
        return true;
    }
}




// remove the extra space from the end of a string (this happens to the last dependancy on a line)
char * removeWhiteSpace(char * text){
    if((text[strlen(text)-1] == ' ') || (text[strlen(text)-1] == '\n')){
        char * substring = malloc(sizeof(char) * (strlen(text)-1));
        strncpy(substring, text, strlen(text)-1);
        return substring;
    }
    else{
        return text;
    }
}





/*
 files stores all the dependancies from the target lines (starting from index 1). index 0 is (target:)
 
 rebuildFile, stores all the files needing to be rebuilt
 
 if index 0 has a ":" character on the end, then this target has no dependancies
 
 */

char *files[300][300];
char *rebuildFile[300];
int rebuildCount = 0;

void targetLines(){
    FILE *fp;
    fp = fopen("Bakefile.txt", "r");
    int targetCount = 0;
    
    if(fp != NULL) {
        char line[BUFSIZ];
        
        while( fgets(line, sizeof line, fp) != NULL) {
            for(int i=0; line[i] != '\0'; i++) {
                if (line[i] == ':'){
                    ++targetCount;
                    char *fileName;
                    fileName = strtok(line, " ");
                    int i = 0;
                    while (fileName != NULL)
                    {
                        // if i==0 then create a new array for target line
                        fileName = removeWhiteSpace(fileName);
                        if(*fileName != ':'){
                            // if file does not exist and is not (target:), but dependancy
                            if(!fileExists(fileName)){
                                files[targetCount][i] = fileName;
                                printf("files[%i][%i]: %s\n",targetCount, i, files[targetCount][i]);
                                if((i != 0) && (targetCount==1)){
                                    rebuildFile[rebuildCount] = fileName;
                                    printf("rebuildFile[%i]: %s\n", rebuildCount, rebuildFile[rebuildCount]);
                                    ++rebuildCount;
                                }
                                else if((i != 0) && (targetCount>1)){
                                    perror("Cannot rebuild the file/target, because one or more of its dependancies dont exist.");
                                    // ABORT REBUILDING HERE
                                }
                            }
                            // if the file exists, then save it for later
                            else if(fileExists(fileName)){
                                files[targetCount][i] = fileName;
                                printf("files[%i][%i]: %s\n",targetCount, i, files[targetCount][i]);
                            }
                            i++;
                        }
                        fileName = strtok(NULL, " ");
                    }
                }
            }
        }
    }
    printf("\n\n");
    printf("files[%i][%i]: %s\n",1, 0, files[1][0]);
}

/*
 for each file in the target lines
 if DEPENDANCY does not exist, rebuild.
 rebuild it by further searching for dependancy target line.
 once target line has been found, check if these new dependancies exist and go to line after (action line)
 
 if DEPENDANCY does exist, store in files[]
 for each file in files[]
 if dependancy (i.e > 1) is newer than target (=0), rebuild
 
 
 */




int main(int argc, char *argv[]){
    targetLines();
    // testMethod();
    
}


